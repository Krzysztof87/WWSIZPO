﻿namespace Lamps.Interfaces
{
    interface ILampThatBeeps
    {
        void DoBeep();
    }
}