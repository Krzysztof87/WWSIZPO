﻿using System;

namespace Lamps
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}